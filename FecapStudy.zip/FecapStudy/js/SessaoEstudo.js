// =============================================================
// Missão 4 — Polimorfismo Dinâmico (sobrescrita)
// Cada modalidade de estudo sabe calcular o próprio XP e montar
// o próprio feedback. Nada de if (modalidade == ...)!
// =============================================================

class SessaoEstudo {
    #disciplina;      // referência para um objeto Disciplina (Missão 1)
    #duracaoMinutos;

    constructor(disciplina, duracaoMinutos) {
        if (new.target === SessaoEstudo) {
            throw new Error("SessaoEstudo é uma classe abstrata e não pode ser instanciada!");
        }
        this.#disciplina = disciplina;
        this.#duracaoMinutos = duracaoMinutos;
    }

    getDisciplina() { return this.#disciplina; }
    getDuracaoMinutos() { return this.#duracaoMinutos; }

    // Métodos "abstratos"
    obterModalidade() {
        throw new Error("Método abstrato obterModalidade() precisa ser sobrescrito.");
    }

    calcularXp() {
        throw new Error("Método abstrato calcularXp() precisa ser sobrescrito.");
    }

    // Método "virtual": tem um comportamento padrão, mas as filhas podem sobrescrever
    gerarFeedback() {
        return `${this.obterModalidade()} em ${this.#disciplina.getNome()} ` +
               `(${this.#duracaoMinutos} min) -> +${this.calcularXp()} XP`;
    }

    // Missão 6 — implementa IExportavelJson
    // Os nomes dos campos já batem com o que o Backend espera em POST /api/sessoes
    paraJson() {
        return JSON.stringify({
            disciplina: this.#disciplina.getNome(),
            tipoModalidade: this.obterModalidade(),
            duracaoMinutos: this.#duracaoMinutos,
            xpGanho: this.calcularXp(),
            resumoFeedback: this.gerarFeedback()
        });
    }
}


class SessaoPomodoro extends SessaoEstudo {
    #ciclosCompletos;

    constructor(disciplina, duracaoMinutos, ciclosCompletos) {
        super(disciplina, duracaoMinutos);
        this.#ciclosCompletos = ciclosCompletos;
    }

    getCiclosCompletos() { return this.#ciclosCompletos; }

    obterModalidade() {
        return "Pomodoro";
    }

    // XP = duração * 2 + ciclos * 15
    calcularXp() {
        return this.getDuracaoMinutos() * 2 + this.#ciclosCompletos * 15;
    }

    // Reaproveita o feedback da mãe e só acrescenta o detalhe
    gerarFeedback() {
        return `${super.gerarFeedback()} | ${this.#ciclosCompletos} ciclo(s) concluído(s)`;
    }
}


class SessaoExercicios extends SessaoEstudo {
    #totalQuestoes;
    #acertos;

    constructor(disciplina, duracaoMinutos, totalQuestoes, acertos) {
        super(disciplina, duracaoMinutos);
        this.#totalQuestoes = totalQuestoes;
        // Não dá para acertar mais questões do que existem
        this.#acertos = Math.min(acertos, totalQuestoes);
    }

    getTotalQuestoes() { return this.#totalQuestoes; }
    getAcertos() { return this.#acertos; }

    obterModalidade() {
        return "Exercícios";
    }

    // XP = duração + acertos * 10
    calcularXp() {
        return this.getDuracaoMinutos() + this.#acertos * 10;
    }

    gerarFeedback() {
        const percentual = this.#totalQuestoes > 0
            ? Math.round((this.#acertos / this.#totalQuestoes) * 100)
            : 0;
        return `${super.gerarFeedback()} | ${this.#acertos}/${this.#totalQuestoes} acertos (${percentual}%)`;
    }
}


class SessaoLeitura extends SessaoEstudo {
    #paginasLidas;
    #fezResumo;

    constructor(disciplina, duracaoMinutos, paginasLidas, fezResumo) {
        super(disciplina, duracaoMinutos);
        this.#paginasLidas = paginasLidas;
        this.#fezResumo = fezResumo;
    }

    getPaginasLidas() { return this.#paginasLidas; }
    getFezResumo() { return this.#fezResumo; }

    obterModalidade() {
        return "Leitura";
    }

    // XP = duração + páginas * 3 + 25 se fez resumo
    calcularXp() {
        return this.getDuracaoMinutos() + this.#paginasLidas * 3 + (this.#fezResumo ? 25 : 0);
    }

    // Não sobrescreve gerarFeedback(): usa o padrão da classe mãe
}