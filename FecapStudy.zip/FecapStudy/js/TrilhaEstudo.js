// =============================================================
// Missão 7 — Agregação (TrilhaEstudo ◇── Disciplina)
// A trilha REÚNE disciplinas que já existem no catálogo.
// Se a trilha for apagada, as disciplinas continuam existindo.
// =============================================================

class TrilhaEstudo {
    #titulo;
    #administrador;      // Associação: o Administrador responsável pela trilha
    #disciplinas = [];   // Agregação: disciplinas criadas FORA da trilha

    constructor(titulo, administrador) {
        this.#titulo = titulo;
        this.#administrador = administrador;
    }

    getTitulo() { return this.#titulo; }
    getAdministrador() { return this.#administrador; }
    getDisciplinas() { return [...this.#disciplinas]; } // cópia

    // Recebe a disciplina PRONTA (não tem new Disciplina aqui dentro!)
    adicionarDisciplina(disciplina) {
        if (!(disciplina instanceof Disciplina)) return false;
        if (this.#disciplinas.includes(disciplina)) return false; // sem duplicar
        this.#disciplinas.push(disciplina);
        return true;
    }

    // Soma as horas semanais de todas as disciplinas da trilha
    calcularCargaHorariaTotal() {
        let total = 0;
        for (const d of this.#disciplinas) {
            total += d.getCargaHorariaSemanalHoras();
        }
        return total;
    }

    exibirResumo() {
        return `Trilha "${this.#titulo}" (resp.: ${this.#administrador.getNome()}) — ` +
               `${this.#disciplinas.length} disciplina(s), ${this.calcularCargaHorariaTotal()}h/semana`;
    }
}