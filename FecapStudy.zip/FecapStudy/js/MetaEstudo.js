// =============================================================
// Missão 2 — Encapsulamento
// A meta semanal fica blindada: ninguém altera os minutos direto,
// só pelos métodos que validam as regras de negócio.
// =============================================================

class MetaEstudo {
    #metaMinutosSemana;
    #minutosCumpridos = 0; // sempre começa em 0

    constructor(metaMinutosSemana) {
        // Reaproveita a validação em vez de repetir o if/else aqui
        this.redefinirMeta(metaMinutosSemana);
    }

    // Getters (só leitura). NÃO existe setMinutosCumpridos!
    getMetaMinutosSemana() { return this.#metaMinutosSemana; }
    getMinutosCumpridos() { return this.#minutosCumpridos; }

    // Única forma de somar minutos estudados
    registrarAvanco(minutos) {
        if (!Number.isInteger(minutos)) return false; // precisa ser número inteiro
        if (minutos <= 0) return false;               // zero ou negativo
        if (minutos > 480) return false;              // mais de 8h seguidas: provável erro

        this.#minutosCumpridos += minutos;
        return true;
    }

    // Usado pelo Responsável. Trava a meta entre 30 e 3000 minutos
    redefinirMeta(novaMeta) {
        if (typeof novaMeta !== "number" || Number.isNaN(novaMeta) || novaMeta < 30) {
            this.#metaMinutosSemana = 30;
        } else if (novaMeta > 3000) {
            this.#metaMinutosSemana = 3000;
        } else {
            this.#metaMinutosSemana = novaMeta;
        }
    }

    // De 0 a 100.0, travando em 100 mesmo se estudar além da meta
    calcularPercentual() {
        const percentual = (this.#minutosCumpridos / this.#metaMinutosSemana) * 100;
        return Math.min(percentual, 100.0);
    }

    estaCumprida() {
        return this.#minutosCumpridos >= this.#metaMinutosSemana;
    }

    // Missão 6 — implementa IExportavelJson
    paraJson() {
        return JSON.stringify({
            metaMinutosSemana: this.#metaMinutosSemana,
            minutosCumpridos: this.#minutosCumpridos,
            percentual: this.calcularPercentual(),
            cumprida: this.estaCumprida()
        });
    }
}