// =============================================================
// Missão 3 — Classe Abstrata e Herança
// Não existe "usuário genérico": toda pessoa é Administrador,
// Responsavel ou Discente.
// =============================================================

class Usuario {
    #id;
    #nome;
    #email;
    #senha; // totalmente privada: NÃO tem getter!

    constructor(id, nome, email, senha) {
        // JS não tem "abstract": bloqueamos o new Usuario(...) na mão
        if (new.target === Usuario) {
            throw new Error("Usuario é uma classe abstrata e não pode ser instanciada!");
        }
        this.#id = id;
        this.#nome = nome;
        this.#email = email;
        this.#senha = senha;
    }

    getId() { return this.#id; }
    getNome() { return this.#nome; }
    getEmail() { return this.#email; }

    // Método concreto: compara a senha sem nunca expô-la
    autenticar(senhaDigitada) {
        return senhaDigitada === this.#senha;
    }

    // Métodos "abstratos": as filhas são obrigadas a sobrescrever
    obterTipoPerfil() {
        throw new Error("Método abstrato obterTipoPerfil() precisa ser sobrescrito.");
    }

    gerarPainelResumo() {
        throw new Error("Método abstrato gerarPainelResumo() precisa ser sobrescrito.");
    }
}


class Administrador extends Usuario {
    #cargo;

    constructor(id, nome, email, senha, cargo) {
        super(id, nome, email, senha);
        this.#cargo = cargo;
    }

    getCargo() { return this.#cargo; }

    obterTipoPerfil() {
        return "Administrador";
    }

    gerarPainelResumo() {
        return `[${this.obterTipoPerfil()}] ${this.getNome()} (${this.getEmail()}) — Cargo: ${this.#cargo}`;
    }
}


class Responsavel extends Usuario {
    #parentesco;
    #discentes = [];       // Missão 7: Associação Responsavel ——> Discente
    #metas = new Map();    // Missão 7: meta de cada discente (Discente -> MetaEstudo)

    constructor(id, nome, email, senha, parentesco) {
        super(id, nome, email, senha);
        this.#parentesco = parentesco;
    }

    getParentesco() { return this.#parentesco; }

    // Devolve uma cópia da lista
    getDiscentes() { return [...this.#discentes]; }

    // ---------------------------------------------------------
    // Missão 7 — Associação
    // O Discente é criado FORA e só é vinculado aqui (sem duplicar).
    // ---------------------------------------------------------
    vincularDiscente(discente) {
        if (!(discente instanceof Discente)) return false;
        if (this.#discentes.includes(discente)) return false; // já vinculado
        this.#discentes.push(discente);
        return true;
    }

    // Guarda a meta semanal de um discente acompanhado
    definirMeta(discente, meta) {
        if (!this.#discentes.includes(discente)) return false; // só para discentes vinculados
        if (!(meta instanceof MetaEstudo)) return false;
        this.#metas.set(discente, meta);
        return true;
    }

    obterMeta(discente) {
        return this.#metas.get(discente) ?? null;
    }

    obterTipoPerfil() {
        return "Responsável";
    }

    gerarPainelResumo() {
        return `[${this.obterTipoPerfil()}] ${this.getNome()} (${this.getEmail()}) — ` +
               `Parentesco: ${this.#parentesco} | Acompanha: ${this.#discentes.length} discente(s)`;
    }
}

class Discente extends Usuario {
    #ra;
    #xpTotal = 0;     // começa em 0
    #historico = [];  // Missão 5: sessões de estudo realizadas

    constructor(id, nome, email, senha, ra) {
        super(id, nome, email, senha);
        this.#ra = ra;
    }

    getRa() { return this.#ra; }
    getXpTotal() { return this.#xpTotal; }

    // Devolve uma CÓPIA, para ninguém mexer no histórico de fora
    getHistorico() { return [...this.#historico]; }

    // Só aceita pontos positivos (encapsulamento da Aula 5)
    adicionarXp(pontos) {
        if (!Number.isInteger(pontos) || pontos <= 0) return false;
        this.#xpTotal += pontos;
        return true;
    }

    // ---------------------------------------------------------
    // Missão 5 — Polimorfismo Estático (Sobrecarga)
    // JS não permite 3 métodos com o mesmo nome, então um único
    // método descobre qual "forma" foi chamada pelos argumentos.
    //
    //   Forma 1: registrarEstudo(sessao)
    //   Forma 2: registrarEstudo(disciplina, minutos)
    //   Forma 3: registrarEstudo(disciplina, horaInicio, horaFim, paginasLidas)
    // ---------------------------------------------------------
    registrarEstudo(arg1, arg2, arg3, arg4) {
        // Forma 1: recebeu uma sessão pronta
        if (arg1 instanceof SessaoEstudo) {
            const sessao = arg1;
            this.#historico.push(sessao);
            this.adicionarXp(sessao.calcularXp());
            return sessao;
        }

        // Forma 2 (atalho rápido): disciplina + minutos -> Pomodoro padrão
        if (arg1 instanceof Disciplina && arg3 === undefined) {
            const minutos = arg2;
            const ciclos = Math.max(1, Math.floor(minutos / 25)); // mínimo 1 ciclo
            return this.registrarEstudo(new SessaoPomodoro(arg1, minutos, ciclos));
        }

        // Forma 3 (por horário): disciplina + início + fim + páginas -> Leitura com resumo
        if (arg1 instanceof Disciplina && arg4 !== undefined) {
            const horaInicio = arg2;
            const horaFim = arg3;
            if (horaFim <= horaInicio) return null; // horário inválido
            const minutos = (horaFim - horaInicio) * 60;
            return this.registrarEstudo(new SessaoLeitura(arg1, minutos, arg4, true));
        }

        return null; // nenhuma forma reconhecida
    }

    obterTipoPerfil() {
        return "Discente";
    }

    gerarPainelResumo() {
        return `[${this.obterTipoPerfil()}] ${this.getNome()} — RA: ${this.#ra} | XP: ${this.#xpTotal}`;
    }
}