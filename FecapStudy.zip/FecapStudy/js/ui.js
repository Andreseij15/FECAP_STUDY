// =============================================================
// Missão 9 — Interface Gráfica (HTML + CSS + DOM)
//
// Regra de ouro (Aula 4): a TELA só lê os campos, cria objetos e
// mostra resultados. Fórmulas de XP, percentual da meta e regras
// de validação continuam DENTRO das classes de domínio.
// =============================================================


// ---------- 1. Objetos de domínio ----------
const disciplinas = [
    new Disciplina("ADS301", "Banco de Dados Avançado", "Dados", 4),
    new Disciplina("ADS302", "Desenvolvimento Web Full Stack", "Computação", 4),
    new Disciplina("ADS303", "Design de Interface Digital", "Design", 4),
    new Disciplina("ADS304", "Estrutura de Dados", "Computação", 4),
    new Disciplina("ADS305", "Programação Orientada a Objetos", "Computação", 4),
    new Disciplina("ADS306", "Expert System Certification", "Certificação", 4)
];

const discente = new Discente(3, "André Shiroma", "andre@fecap.br", "aluno123", "RA-101");
const responsavel = new Responsavel(2, "Carlos Souza", "carlos@email.com", "resp123", "Pai");

const meta = new MetaEstudo(600);
responsavel.vincularDiscente(discente);   // Associação (Missão 7)
responsavel.definirMeta(discente, meta);

const servicoAlerta = new ServicoAlertaResponsavel(); // Dependência (Missão 8)
const cliente = new ClienteBackendEstudo("http://localhost:5080"); // Missão 10

// Um notificador de cada canal (todos cumprem o contrato INotificador)
const notificadores = {
    Email: new NotificadorEmail(),
    WhatsApp: new NotificadorWhatsApp(),
    Painel: new NotificadorPainel()
};

// Cada modalidade sabe montar a sua subclasse. A tela não calcula XP!
const fabricasDeSessao = {
    Pomodoro: (disciplina, minutos) =>
        new SessaoPomodoro(disciplina, minutos, lerNumero("inp-ciclos")),
    Exercicios: (disciplina, minutos) =>
        new SessaoExercicios(disciplina, minutos, lerNumero("inp-questoes"), lerNumero("inp-acertos")),
    Leitura: (disciplina, minutos) =>
        new SessaoLeitura(disciplina, minutos, lerNumero("inp-paginas"), el("chk-resumo").checked)
};


// ---------- 2. Atalhos para o DOM ----------
function el(id) {
    return document.getElementById(id);
}

function lerNumero(id) {
    return Number(el(id).value);
}

function mostrarMensagem(texto, tipo) {
    const msg = el("msg-form");
    msg.textContent = texto;
    msg.className = `msg ${tipo}`;
}

let timerToast;
function mostrarToast(texto) {
    const toast = el("toast");
    toast.textContent = texto;
    toast.classList.add("visivel");
    clearTimeout(timerToast);
    timerToast = setTimeout(() => toast.classList.remove("visivel"), 4000);
}


// ---------- 3. Atualização da tela a partir dos objetos ----------
function atualizarPerfis() {
    el("painel-discente").textContent = discente.gerarPainelResumo();
    el("painel-responsavel").textContent = responsavel.gerarPainelResumo();
}

function atualizarMeta() {
    const percentual = meta.calcularPercentual();
    el("barra-preenchida").style.width = `${percentual}%`;
    el("barra-meta").setAttribute("aria-valuenow", percentual.toFixed(0));
    el("barra-meta").classList.toggle("cumprida", meta.estaCumprida());

    el("texto-meta").textContent =
        `${meta.getMinutosCumpridos()} de ${meta.getMetaMinutosSemana()} min ` +
        `(${percentual.toFixed(0)}%)` + (meta.estaCumprida() ? " — meta cumprida!" : "");
}

function atualizarHistorico() {
    const lista = el("lista-historico");
    lista.innerHTML = "";

    const historico = discente.getHistorico();
    // Mais recente primeiro
    for (const sessao of [...historico].reverse()) {
        const li = document.createElement("li");
        li.textContent = sessao.gerarFeedback(); // polimorfismo: cada sessão monta o seu
        lista.appendChild(li);
    }
    el("historico-vazio").hidden = historico.length > 0;
}

function atualizarTela() {
    atualizarPerfis();
    atualizarMeta();
    atualizarHistorico();
}


// ---------- 4. Montagem inicial ----------
function preencherDisciplinas() {
    const select = el("sel-disciplina");
    disciplinas.forEach((d, indice) => {
        const option = document.createElement("option");
        option.value = indice;
        option.textContent = d.getNome();
        select.appendChild(option);
    });
}

// Mostra só os campos extras da modalidade escolhida
function trocarCamposExtras() {
    const modalidade = el("sel-modalidade").value;
    for (const bloco of document.querySelectorAll(".extra")) {
        bloco.hidden = bloco.dataset.modalidade !== modalidade;
    }
}


// ---------- 5. Eventos ----------
function registrarEstudo(evento) {
    evento.preventDefault();

    const disciplina = disciplinas[lerNumero("sel-disciplina")];
    const modalidade = el("sel-modalidade").value;
    const minutos = lerNumero("inp-duracao");

    // Campos extras da modalidade precisam ser inteiros >= 0 (questões >= 1)
    const camposExtras = {
        Pomodoro: [["inp-ciclos", 0]],
        Exercicios: [["inp-questoes", 1], ["inp-acertos", 0]],
        Leitura: [["inp-paginas", 0]]
    };
    for (const [id, minimo] of camposExtras[modalidade]) {
        const valor = lerNumero(id);
        if (!Number.isInteger(valor) || valor < minimo) {
            mostrarMensagem("Confira os campos da modalidade: use números inteiros e não negativos.", "erro");
            return;
        }
    }

    // 1º a meta valida os minutos (encapsulamento: regra mora na MetaEstudo)
    if (!meta.registrarAvanco(minutos)) {
        mostrarMensagem("Duração inválida: informe um número inteiro entre 1 e 480 minutos.", "erro");
        return;
    }

    // 2º cria a subclasse certa e o discente registra (Forma 1 da sobrecarga)
    const sessao = fabricasDeSessao[modalidade](disciplina, minutos);
    discente.registrarEstudo(sessao);

    mostrarMensagem(`Registrado! +${sessao.calcularXp()} XP · enviando ao servidor…`, "sucesso");
    atualizarTela();

    // 3º Missão 10: grava no Backend (POST /api/sessoes)
    enviarSessaoAoServidor(sessao);
}

async function enviarSessaoAoServidor(sessao) {
    try {
        const salva = await cliente.salvarSessao(discente.getNome(), sessao);
        mostrarMensagem(`Registrado! +${sessao.calcularXp()} XP · salvo no servidor (id ${salva.id})`, "sucesso");
        atualizarStatusServidor();
    } catch (erro) {
        mostrarMensagem(`Registrado só nesta tela (+${sessao.calcularXp()} XP). ` +
                        `Servidor indisponível: inicie o iniciar_backend.bat.`, "erro");
        marcarServidorOffline();
    }
}

function notificarResponsavel() {
    const canal = el("sel-canal").value;
    const notificador = notificadores[canal];

    const enviado = servicoAlerta.avaliarDiscente(discente, meta, responsavel, notificador);

    if (enviado) {
        const pct = meta.calcularPercentual().toFixed(0);
        mostrarToast(`${notificador.obterCanal()} enviado para ${responsavel.getEmail()}: ` +
                     `${discente.getNome()} está com ${pct}% da meta.`);
    } else {
        mostrarToast("Não foi possível enviar o alerta.");
    }
}

async function redefinirMeta() {
    meta.redefinirMeta(lerNumero("inp-meta")); // a classe trava entre 30 e 3000
    el("inp-meta").value = meta.getMetaMinutosSemana();
    atualizarMeta();

    try {
        await cliente.salvarMeta(discente.getNome(), responsavel.getNome(), meta); // POST /api/metas
        mostrarToast(`Meta semanal ajustada para ${meta.getMetaMinutosSemana()} min e salva no servidor.`);
    } catch (erro) {
        mostrarToast(`Meta ajustada para ${meta.getMetaMinutosSemana()} min (servidor indisponível).`);
        marcarServidorOffline();
    }
}


// ---------- 6. Missão 10: servidor ----------
function marcarServidorOffline() {
    const status = el("status-servidor");
    status.textContent = "offline";
    status.className = "status offline";
}

async function atualizarStatusServidor() {
    const status = el("status-servidor");
    try {
        const info = await cliente.verificarStatus(); // GET /api/status
        status.textContent = info.usandoMySql ? "online · MySQL" : "online · JSON local";
        status.className = "status online";
        return true;
    } catch (erro) {
        marcarServidorOffline();
        return false;
    }
}

// Ao abrir a tela: confere o servidor e garante que a meta do discente
// existe lá (o backend só soma minutos em metas já cadastradas).
async function conectarServidor() {
    const online = await atualizarStatusServidor();
    if (!online) return;

    try {
        const metas = await cliente.listarMetas(discente.getNome()); // GET /api/metas
        if (metas.length === 0) {
            await cliente.salvarMeta(discente.getNome(), responsavel.getNome(), meta);
        }
    } catch (erro) {
        marcarServidorOffline();
    }
}

// Botão "Carregar Histórico do Servidor / Relatório"
async function carregarRelatorio() {
    const botao = el("btn-carregar");
    botao.disabled = true;
    botao.textContent = "Carregando…";

    try {
        const rel = await cliente.obterRelatorio(discente.getNome()); // GET /api/relatorio/{nome}

        el("rel-sessoes").textContent = rel.totalSessoes;
        el("rel-minutos").textContent = rel.totalMinutosEstudados;
        el("rel-xp").textContent = rel.totalXpAcumulado;
        el("rel-meta").textContent = `${rel.percentualMetaConcluida}%`;
        el("rel-status").textContent =
            `${rel.statusAcompanhamento} (meta no servidor: ${rel.metaMinutosSemana} min/semana)`;

        const lista = el("rel-lista");
        lista.innerHTML = "";
        for (const s of rel.sessoesRecentes) {
            const li = document.createElement("li");
            li.textContent = `${s.dataRegistro} · ${s.resumoFeedback}`;
            lista.appendChild(li);
        }
        if (rel.sessoesRecentes.length === 0) {
            const li = document.createElement("li");
            li.textContent = "Nenhuma sessão gravada no servidor ainda.";
            lista.appendChild(li);
        }

        el("relatorio").hidden = false;
        atualizarStatusServidor();
    } catch (erro) {
        mostrarToast("Não foi possível falar com o servidor. Ele está rodando em http://localhost:5080?");
        marcarServidorOffline();
    } finally {
        botao.disabled = false;
        botao.textContent = "Carregar Histórico do Servidor / Relatório";
    }
}


// ---------- 7. Inicialização ----------
preencherDisciplinas();
trocarCamposExtras();
atualizarTela();
conectarServidor();

el("sel-modalidade").addEventListener("change", trocarCamposExtras);
el("form-sessao").addEventListener("submit", registrarEstudo);
el("btn-notificar").addEventListener("click", notificarResponsavel);
el("btn-meta").addEventListener("click", redefinirMeta);
el("btn-carregar").addEventListener("click", carregarRelatorio);
