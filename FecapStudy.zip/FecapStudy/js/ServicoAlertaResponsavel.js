// =============================================================
// Missão 8 — Dependência (ServicoAlertaResponsavel - - -> ...)
// O serviço USA Discente, MetaEstudo, Responsavel e INotificador
// apenas durante o método. Não guarda nenhum deles em atributos.
// =============================================================

class ServicoAlertaResponsavel {
    // Sem campos de instância!

    avaliarDiscente(discente, meta, responsavel, notificador) {
        if (!verificarNotificador(notificador)) return false;

        const percentual = meta.calcularPercentual();
        let mensagem;

        if (meta.estaCumprida()) {
            mensagem = `Parabéns! ${discente.getNome()} atingiu 100% da meta semanal ` +
                       `(${meta.getMinutosCumpridos()}/${meta.getMetaMinutosSemana()} min).`;
        } else {
            mensagem = `${discente.getNome()} está com ${percentual.toFixed(0)}% da meta semanal ` +
                       `(${meta.getMinutosCumpridos()}/${meta.getMetaMinutosSemana()} min).`;
        }

        // Não importa se é E-mail, WhatsApp ou Painel: o contrato é o mesmo
        return notificador.enviarAlerta(responsavel.getEmail(), mensagem);
    }
}