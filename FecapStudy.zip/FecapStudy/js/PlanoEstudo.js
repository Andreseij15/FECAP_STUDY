// =============================================================
// Missão 8 — Composição (PlanoEstudo ◆── ItemCronograma)
// O ItemCronograma NASCE dentro do PlanoEstudo e não existe fora dele.
// Ninguém de fora recebe referência para os itens.
// =============================================================

class ItemCronograma {
    #diaSemana;
    #minutosPlanejados;

    constructor(diaSemana, minutosPlanejados) {
        this.#diaSemana = diaSemana;
        this.#minutosPlanejados = minutosPlanejados;
    }

    getDiaSemana() { return this.#diaSemana; }
    getMinutosPlanejados() { return this.#minutosPlanejados; }

    exibir() {
        return `${this.#diaSemana}: ${this.#minutosPlanejados} min`;
    }
}


class PlanoEstudo {
    static DIAS_VALIDOS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"];

    #titulo;
    #itens = []; // Composição: só o PlanoEstudo cria e guarda os itens

    constructor(titulo) {
        this.#titulo = titulo;
    }

    getTitulo() { return this.#titulo; }

    // Recebe dados PRIMITIVOS e faz o new ItemCronograma aqui dentro
    adicionarItem(diaSemana, minutos) {
        if (!PlanoEstudo.DIAS_VALIDOS.includes(diaSemana)) return false;
        if (!Number.isInteger(minutos) || minutos <= 0 || minutos > 480) return false;

        this.#itens.push(new ItemCronograma(diaSemana, minutos));
        return true;
    }

    // NÃO existe getItens(): de fora só dá para ler textos e totais
    listarItens() {
        return this.#itens.map(item => item.exibir());
    }

    getQuantidadeItens() {
        return this.#itens.length;
    }

    calcularTotalMinutosPlanejados() {
        let total = 0;
        for (const item of this.#itens) {
            total += item.getMinutosPlanejados();
        }
        return total;
    }
}