// =============================================================
// Missão 6 — Interfaces (contratos)
// JavaScript não tem a palavra-chave "interface". Então:
//   1) documentamos o contrato aqui;
//   2) criamos funções que verificam se um objeto cumpre o contrato
//      (Duck Typing: "se anda como pato e grasna como pato, é pato").
// =============================================================

/*
 * «interface» INotificador
 *   obterCanal(): string
 *   enviarAlerta(destinatario: string, mensagem: string): boolean
 */
function verificarNotificador(obj) {
    return obj != null &&
           typeof obj.obterCanal === "function" &&
           typeof obj.enviarAlerta === "function";
}

/*
 * «interface» IExportavelJson
 *   paraJson(): string
 */
function verificarExportavelJson(obj) {
    return obj != null && typeof obj.paraJson === "function";
}