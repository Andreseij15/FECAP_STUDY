// =============================================================
// app.js — programa principal / lógica da tela
// Por enquanto: teste da Missão 1. Na Missão 9 vira a tela completa.
// =============================================================

// ---------- Missão 1: instanciando as disciplinas ----------
// Matérias do semestre. Cada aula dura 3h40 por semana
// (19:00–22:40; Expert System 9:00–12:40), arredondado para 4h inteiras.
const bdAvancado = new Disciplina("ADS301", "Banco de Dados Avançado", "Dados", 4);
const webFullStack = new Disciplina("ADS302", "Desenvolvimento Web Full Stack", "Computação", 4);
const designInterface = new Disciplina("ADS303", "Design de Interface Digital", "Design", 4);
const estruturaDados = new Disciplina("ADS304", "Estrutura de Dados", "Computação", 4);
const poo = new Disciplina("ADS305", "Programação Orientada a Objetos", "Computação", 4);
const expertSystem = new Disciplina("ADS306", "Expert System Certification", "Certificação", 4);

const disciplinas = [bdAvancado, webFullStack, designInterface, estruturaDados, poo, expertSystem];

// Objeto só para testar a regra do construtor (carga inválida -> vira 2h)
const teste = new Disciplina("TESTE", "Disciplina de Teste", "Teste", -4);

// Mostra no console (F12) e na página
const listaMissao1 = document.getElementById("lista-missao1");

for (const d of disciplinas) {
    console.log(d.exibirResumo());

    const li = document.createElement("li");
    li.textContent = d.exibirResumo();
    listaMissao1.appendChild(li);
}

// Checklist da Missão 1
console.log(teste.exibirResumo());
console.log("Carga corrigida para 2h?", teste.getCargaHorariaSemanalHoras() === 2);
console.log("Objetos independentes?", poo.getNome() !== bdAvancado.getNome());



// ---------- Missão 2: teste de mesa da MetaEstudo ----------
const saidaMissao2 = document.getElementById("saida-missao2");

function mostrarM2(texto) {
    console.log(texto);
    const li = document.createElement("li");
    li.textContent = texto;
    saidaMissao2.appendChild(li);
}

const meta = new MetaEstudo(100);
mostrarM2(`Meta criada: ${meta.getMetaMinutosSemana()} min/semana`);

mostrarM2(`registrarAvanco(-20) -> ${meta.registrarAvanco(-20)}`);   // false
mostrarM2(`registrarAvanco(900) -> ${meta.registrarAvanco(900)}`);   // false
mostrarM2(`Minutos cumpridos após tentativas inválidas: ${meta.getMinutosCumpridos()}`); // 0

mostrarM2(`registrarAvanco(60) -> ${meta.registrarAvanco(60)}`);     // true
mostrarM2(`Percentual: ${meta.calcularPercentual()}%`);              // 60%
mostrarM2(`Meta cumprida? ${meta.estaCumprida()}`);                  // false

meta.registrarAvanco(80);                                            // passa da meta
mostrarM2(`Depois de +80 min: ${meta.calcularPercentual()}% (trava em 100)`);
mostrarM2(`Meta cumprida? ${meta.estaCumprida()}`);                  // true

// Tentativa de "sabotagem": o campo privado não pode ser alterado de fora
meta.minutosCumpridos = 99999; // cria uma propriedade pública qualquer, não mexe no #privado
mostrarM2(`Após meta.minutosCumpridos = 99999 -> getMinutosCumpridos(): ${meta.getMinutosCumpridos()}`);

// Limites do redefinirMeta
const metaBaixa = new MetaEstudo(-100);
const metaAlta = new MetaEstudo(5000);
mostrarM2(`new MetaEstudo(-100) -> ${metaBaixa.getMetaMinutosSemana()} min (mínimo 30)`);
mostrarM2(`new MetaEstudo(5000) -> ${metaAlta.getMetaMinutosSemana()} min (máximo 3000)`);



// ---------- Missão 3: perfis de usuário ----------
const saidaMissao3 = document.getElementById("saida-missao3");

function mostrarM3(texto) {
    console.log(texto);
    const li = document.createElement("li");
    li.textContent = texto;
    saidaMissao3.appendChild(li);
}

// 1) Usuario é abstrata: tentar instanciar deve dar erro
try {
    new Usuario(0, "Genérico", "x@fecap.br", "123");
    mostrarM3("ERRO: conseguiu instanciar Usuario!");
} catch (e) {
    mostrarM3(`new Usuario(...) bloqueado -> "${e.message}"`);
}

// 2) Os três perfis concretos
const admin = new Administrador(1, "Ana Lima", "ana.lima@fecap.br", "admin123", "Coordenação PI");
const responsavel = new Responsavel(2, "Carlos Souza", "carlos@email.com", "resp123", "Pai");
const discente = new Discente(3, "André Shiroma", "andre@fecap.br", "aluno123", "RA-101");

// 3) Polimorfismo: a mesma chamada, cada um responde do seu jeito
const usuarios = [admin, responsavel, discente];
for (const u of usuarios) {
    mostrarM3(u.gerarPainelResumo());
}

// 4) XP do discente
discente.adicionarXp(65);
discente.adicionarXp(-10); // recusado
mostrarM3(`Após +65 XP (e uma tentativa de -10): ${discente.gerarPainelResumo()}`);

// 5) Senha: autentica, mas não tem como ler
mostrarM3(`autenticar("aluno123") -> ${discente.autenticar("aluno123")}`);
mostrarM3(`autenticar("errada") -> ${discente.autenticar("errada")}`);
mostrarM3(`Existe getSenha()? ${typeof discente.getSenha === "function"}`); // false



// ---------- Missão 4: sessões de estudo (polimorfismo) ----------
const saidaMissao4 = document.getElementById("saida-missao4");

function mostrarM4(texto) {
    console.log(texto);
    const li = document.createElement("li");
    li.textContent = texto;
    saidaMissao4.appendChild(li);
}

// Coleção polimórfica: um tipo de sessão de cada
const sessoes = [
    new SessaoPomodoro(poo, 50, 2),                 // 50*2 + 2*15 = 130 XP
    new SessaoExercicios(estruturaDados, 40, 10, 8), // 40 + 8*10  = 120 XP
    new SessaoLeitura(bdAvancado, 30, 20, true)      // 30 + 20*3 + 25 = 115 XP
];

// Um único laço, SEM nenhum if testando o tipo da sessão
let xpTotalSessoes = 0;
for (const sessao of sessoes) {
    mostrarM4(sessao.gerarFeedback());
    xpTotalSessoes += sessao.calcularXp();
}
mostrarM4(`XP total das sessões: ${xpTotalSessoes}`); // 365



// ---------- Missão 5: sobrecarga do registrarEstudo ----------
const saidaMissao5 = document.getElementById("saida-missao5");

function mostrarM5(texto) {
    console.log(texto);
    const li = document.createElement("li");
    li.textContent = texto;
    saidaMissao5.appendChild(li);
}

mostrarM5(`XP inicial: ${discente.getXpTotal()}`); // 65 (da Missão 3)

// Forma 1: sessão pronta
discente.registrarEstudo(new SessaoExercicios(estruturaDados, 30, 10, 7)); // 30 + 70 = 100 XP
mostrarM5(`Forma 1 (sessão pronta) -> XP: ${discente.getXpTotal()}`);       // 165

// Forma 2: atalho rápido (disciplina + minutos) -> Pomodoro
discente.registrarEstudo(poo, 50); // 2 ciclos: 50*2 + 2*15 = 130 XP
mostrarM5(`Forma 2 (atalho rápido) -> XP: ${discente.getXpTotal()}`);       // 295

// Forma 3: por horário (19h às 21h, 15 páginas) -> Leitura com resumo
discente.registrarEstudo(webFullStack, 19, 21, 15); // 120 + 45 + 25 = 190 XP
mostrarM5(`Forma 3 (por horário) -> XP: ${discente.getXpTotal()}`);         // 485

// Histórico completo
mostrarM5("Histórico do discente:");
for (const s of discente.getHistorico()) {
    mostrarM5(`  • ${s.gerarFeedback()}`);
}
mostrarM5(discente.gerarPainelResumo());



// ---------- Missão 6: interfaces ----------
const saidaMissao6 = document.getElementById("saida-missao6");

function mostrarM6(texto) {
    console.log(texto);
    const li = document.createElement("li");
    li.textContent = texto;
    saidaMissao6.appendChild(li);
}

// INotificador: três classes diferentes, mesmo contrato
const notificadores = [new NotificadorEmail(), new NotificadorWhatsApp(), new NotificadorPainel()];

for (const n of notificadores) {
    if (!verificarNotificador(n)) {
        mostrarM6("Objeto não cumpre o contrato INotificador!");
        continue;
    }
    const enviado = n.enviarAlerta(responsavel.getEmail(), `${discente.getNome()} estudou hoje!`);
    mostrarM6(`Canal ${n.obterCanal()} -> enviado? ${enviado}`);
}

// Mensagem vazia é recusada
mostrarM6(`Alerta com mensagem vazia -> ${notificadores[0].enviarAlerta(responsavel.getEmail(), "")}`);

// Um objeto qualquer NÃO cumpre o contrato
mostrarM6(`{} é um INotificador? ${verificarNotificador({})}`);

// IExportavelJson: SessaoEstudo e MetaEstudo são de famílias diferentes,
// mas as duas sabem se converter para JSON
const exportaveis = [sessoes[0], meta];
for (const obj of exportaveis) {
    if (verificarExportavelJson(obj)) {
        mostrarM6(`JSON: ${obj.paraJson()}`);
    }
}



// ---------- Missão 7: associação e agregação ----------
const saidaMissao7 = document.getElementById("saida-missao7");

function mostrarM7(texto) {
    console.log(texto);
    const li = document.createElement("li");
    li.textContent = texto;
    saidaMissao7.appendChild(li);
}

// Associação: Responsavel ——> Discente (os discentes já existem fora)
const discente2 = new Discente(4, "Beatriz Souza", "beatriz@fecap.br", "aluno456", "RA-102");

mostrarM7(`Vincular ${discente.getNome()} -> ${responsavel.vincularDiscente(discente)}`);      // true
mostrarM7(`Vincular ${discente.getNome()} de novo -> ${responsavel.vincularDiscente(discente)}`); // false (duplicado)
mostrarM7(`Vincular ${discente2.getNome()} -> ${responsavel.vincularDiscente(discente2)}`);    // true
mostrarM7(`Vincular o admin (não é discente) -> ${responsavel.vincularDiscente(admin)}`);       // false

// Meta semanal de cada discente acompanhado
responsavel.definirMeta(discente, new MetaEstudo(600));
responsavel.definirMeta(discente2, new MetaEstudo(300));
for (const d of responsavel.getDiscentes()) {
    mostrarM7(`  • ${d.getNome()} — meta: ${responsavel.obterMeta(d).getMetaMinutosSemana()} min/semana`);
}
mostrarM7(responsavel.gerarPainelResumo());

// Agregação: TrilhaEstudo ◇── Disciplina (as disciplinas vêm do catálogo da Missão 1)
const trilhaSemestre = new TrilhaEstudo("Trilha 3º Semestre ADS", admin);
for (const d of disciplinas) {
    trilhaSemestre.adicionarDisciplina(d);
}
trilhaSemestre.adicionarDisciplina(poo); // duplicada: ignorada
mostrarM7(trilhaSemestre.exibirResumo()); // 6 disciplinas, 24h/semana

// A MESMA disciplina pode estar em outra trilha (prova da agregação)
const trilhaProgramacao = new TrilhaEstudo("Trilha Programação", admin);
trilhaProgramacao.adicionarDisciplina(poo);
trilhaProgramacao.adicionarDisciplina(estruturaDados);
trilhaProgramacao.adicionarDisciplina(webFullStack);
mostrarM7(trilhaProgramacao.exibirResumo()); // 3 disciplinas, 12h/semana

mostrarM7(`POO está nas duas trilhas? ${trilhaSemestre.getDisciplinas().includes(poo) && trilhaProgramacao.getDisciplinas().includes(poo)}`);



// ---------- Missão 8: composição e dependência ----------
const saidaMissao8 = document.getElementById("saida-missao8");

function mostrarM8(texto) {
    console.log(texto);
    const li = document.createElement("li");
    li.textContent = texto;
    saidaMissao8.appendChild(li);
}

// Composição: os itens são criados DENTRO do plano, a partir de dados primitivos
const plano = new PlanoEstudo(`Plano semanal de ${discente.getNome()}`);
plano.adicionarItem("Segunda", 60);
plano.adicionarItem("Quarta", 90);
plano.adicionarItem("Sábado", 120);
mostrarM8(`Dia inválido ("Feriado") -> ${plano.adicionarItem("Feriado", 30)}`); // false
mostrarM8(`Minutos inválidos (-10) -> ${plano.adicionarItem("Sexta", -10)}`);    // false

mostrarM8(`${plano.getTitulo()} — ${plano.getQuantidadeItens()} item(ns), ${plano.calcularTotalMinutosPlanejados()} min planejados`);
for (const texto of plano.listarItens()) {
    mostrarM8(`  • ${texto}`);
}
mostrarM8(`Existe getItens() para mexer nos itens de fora? ${typeof plano.getItens === "function"}`); // false

// Dependência: o serviço só USA os objetos durante o método
const servico = new ServicoAlertaResponsavel();

// André: meta de 600 min, estudou 250 até agora
const metaAndre = responsavel.obterMeta(discente);
metaAndre.registrarAvanco(130);
metaAndre.registrarAvanco(120);

// Beatriz: meta de 300 min, já bateu
const metaBeatriz = responsavel.obterMeta(discente2);
metaBeatriz.registrarAvanco(200);
metaBeatriz.registrarAvanco(150);

// O mesmo serviço funciona com qualquer notificador, sem mudar uma linha
const okEmail = servico.avaliarDiscente(discente, metaAndre, responsavel, new NotificadorEmail());
const okWhats = servico.avaliarDiscente(discente2, metaBeatriz, responsavel, new NotificadorWhatsApp());
mostrarM8(`Alerta do ${discente.getNome()} por E-mail -> enviado? ${okEmail}`);
mostrarM8(`Alerta da ${discente2.getNome()} por WhatsApp -> enviado? ${okWhats}`);

// Painel: guarda as mensagens, então dá para mostrar na tela
const painel = new NotificadorPainel();
servico.avaliarDiscente(discente, metaAndre, responsavel, painel);
servico.avaliarDiscente(discente2, metaBeatriz, responsavel, painel);
for (const msg of painel.getMensagens()) {
    mostrarM8(`  🔔 ${msg}`);
}