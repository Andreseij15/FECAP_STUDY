// =============================================================
// Missão 10 — Conectando a tela ao Backend C# + MySQL
//
// Dependência (- - ->): o cliente NÃO guarda Discente, Sessão ou Meta
// em atributos. Ele só recebe esses objetos como parâmetro, converte
// para JSON e conversa com a API em http://localhost:5080.
// =============================================================

class ClienteBackendEstudo {
    #urlBase;
    #tempoLimiteMs;

    constructor(urlBase = "http://localhost:5080", tempoLimiteMs = 4000) {
        this.#urlBase = urlBase;
        this.#tempoLimiteMs = tempoLimiteMs;
    }

    getUrlBase() { return this.#urlBase; }

    // Método privado que todas as rotas usam: faz o fetch, aplica um
    // tempo limite e transforma erro HTTP em exceção.
    async #requisitar(caminho, opcoes = {}) {
        const controle = new AbortController();
        const timer = setTimeout(() => controle.abort(), this.#tempoLimiteMs);

        try {
            const resposta = await fetch(`${this.#urlBase}${caminho}`, {
                ...opcoes,
                signal: controle.signal
            });
            if (!resposta.ok) {
                throw new Error(`O servidor respondeu HTTP ${resposta.status}`);
            }
            return await resposta.json();
        } finally {
            clearTimeout(timer);
        }
    }

    async #enviarJson(caminho, dados) {
        return this.#requisitar(caminho, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dados)
        });
    }

    // GET /api/status -> { online, usandoMySql, modoBanco, totalSessoes, ... }
    async verificarStatus() {
        return this.#requisitar("/api/status");
    }

    // POST /api/sessoes
    // Usa o paraJson() da sessão (interface IExportavelJson da Missão 6)
    // e só acrescenta o nome do discente.
    async salvarSessao(discenteNome, sessao) {
        if (!verificarExportavelJson(sessao)) {
            throw new Error("A sessão não implementa IExportavelJson.");
        }
        const dados = JSON.parse(sessao.paraJson());
        dados.discenteNome = discenteNome;
        return this.#enviarJson("/api/sessoes", dados);
    }

    // GET /api/sessoes?discente=Nome
    async listarSessoes(discenteNome) {
        return this.#requisitar(`/api/sessoes?discente=${encodeURIComponent(discenteNome)}`);
    }

    // POST /api/metas
    async salvarMeta(discenteNome, responsavelNome, meta) {
        return this.#enviarJson("/api/metas", {
            discenteNome: discenteNome,
            responsavelNome: responsavelNome,
            metaMinutosSemana: meta.getMetaMinutosSemana()
        });
    }

    // GET /api/metas?discente=Nome
    async listarMetas(discenteNome) {
        return this.#requisitar(`/api/metas?discente=${encodeURIComponent(discenteNome)}`);
    }

    // GET /api/relatorio/{nome} -> boletim consolidado do discente
    async obterRelatorio(discenteNome) {
        return this.#requisitar(`/api/relatorio/${encodeURIComponent(discenteNome)}`);
    }
}
