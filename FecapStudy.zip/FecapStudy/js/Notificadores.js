// =============================================================
// Missão 6 — Classes que "assinam" o contrato INotificador
// Famílias diferentes, mesmo contrato: obterCanal() e enviarAlerta().
// Quem usa um notificador não precisa saber COMO a mensagem viaja.
// =============================================================

class NotificadorEmail {
    obterCanal() {
        return "E-mail";
    }

    enviarAlerta(destinatario, mensagem) {
        if (!destinatario || !mensagem) return false;
        // Simulação: num sistema real aqui entraria o envio de e-mail
        console.log(`📧 [E-mail para ${destinatario}] ${mensagem}`);
        return true;
    }
}


class NotificadorWhatsApp {
    obterCanal() {
        return "WhatsApp";
    }

    enviarAlerta(destinatario, mensagem) {
        if (!destinatario || !mensagem) return false;
        console.log(`💬 [WhatsApp para ${destinatario}] ${mensagem}`);
        return true;
    }
}


class NotificadorPainel {
    #mensagens = []; // guarda as notificações exibidas no painel

    obterCanal() {
        return "Painel";
    }

    enviarAlerta(destinatario, mensagem) {
        if (!destinatario || !mensagem) return false;
        this.#mensagens.push(`[${destinatario}] ${mensagem}`);
        console.log(`🔔 [Painel de ${destinatario}] ${mensagem}`);
        return true;
    }

    getMensagens() { return [...this.#mensagens]; }
}