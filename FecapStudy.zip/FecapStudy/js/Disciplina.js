// =============================================================
// Missão 1 — Abstração, Classes e Objetos
// Uma disciplina deixa de ser só um texto solto e vira um objeto
// com código, nome, categoria e carga horária semanal.
// =============================================================

class Disciplina {
    // Campos privados (só acessíveis dentro da classe)
    #codigo;
    #nome;
    #categoria;
    #cargaHorariaSemanalHoras;

    constructor(codigo, nome, categoria, cargaHorariaSemanalHoras) {
        this.#codigo = codigo;
        this.#nome = nome;
        this.#categoria = categoria;

        // Regra: carga <= 0 (ou inválida) assume o padrão de 2 horas
        if (typeof cargaHorariaSemanalHoras !== "number" || cargaHorariaSemanalHoras <= 0) {
            this.#cargaHorariaSemanalHoras = 2;
        } else {
            this.#cargaHorariaSemanalHoras = cargaHorariaSemanalHoras;
        }
    }

    // Getters
    getCodigo() { return this.#codigo; }
    getNome() { return this.#nome; }
    getCategoria() { return this.#categoria; }
    getCargaHorariaSemanalHoras() { return this.#cargaHorariaSemanalHoras; }

    // Converte a carga semanal de horas para minutos
    calcularCargaEmMinutos() {
        return this.#cargaHorariaSemanalHoras * 60;
    }

    // Ex.: "[ADS201] Programação Orientada a Objetos (Computação) — 4h/semana (240 min)"
    exibirResumo() {
        return `[${this.#codigo}] ${this.#nome} (${this.#categoria}) — ` +
               `${this.#cargaHorariaSemanalHoras}h/semana (${this.calcularCargaEmMinutos()} min)`;
    }
}
